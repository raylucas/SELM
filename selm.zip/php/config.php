<?php

	$servidor = "localhost";
	$usuario  = "root";
	$senha    = "";
	$banco    = "selm";

	$mysqli = new mysqli($servidor, $usuario, $senha, $banco); 
	
	
?>